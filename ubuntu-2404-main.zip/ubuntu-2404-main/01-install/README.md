# Curso GRÁTIS de GNU/Linux Ubuntu Server 24.04.x LTS (Noble Numbat)) Essentials

## 💰 Ajude o projeto Bora para Prática a continuar fazendo vídeos e materiais gratuitos para o Canal do YouTUBE
## 💰 Chave PIX do projeto: robsonvaamonde@gmail.com
## 💰 Link de doação do PagSeguro: https://pag.ae/bjlSJcH
## 💰 Link de doação do Paypal: https://www.paypal.com/donate/?hosted_button_id=EALLB7DQ3U6H2

Robson Vaamonde<br>
Procedimentos em TI: http://procedimentosemti.com.br<br>
Bora para Prática: http://boraparapratica.com.br<br>
Robson Vaamonde: http://vaamonde.com.br<br>
Facebook Procedimentos em TI: https://www.facebook.com/ProcedimentosEmTi<br>
Facebook Bora para Prática: https://www.facebook.com/boraparapratica<br>
Instagram Procedimentos em TI: https://www.instagram.com/procedimentoem<br>
YouTUBE Bora Para Prática: https://www.youtube.com/boraparapratica<br>
Linkedin Robson Vaamonde: https://www.linkedin.com/in/robson-vaamonde-0b029028/<br>
Github Procedimentos em TI: https://github.com/vaamonde<br>

<div align="center">
<img alt="GitHub commit activity" src="https://img.shields.io/github/commit-activity/y/vaamonde/ubuntu-2404?style=plastic">
<a href="https://github.com/vaamonde/ubuntu-2404/stargazers"><img src="https://img.shields.io/github/stars/vaamonde/ubuntu-2404" alt="Stars Badge"/></a>
<a href="https://github.com/vaamonde/ubuntu-2404/network/members"><img src="https://img.shields.io/github/forks/vaamonde/ubuntu-2404" alt="Forks Badge"/></a>
<a href="https://github.com/vaamonde/ubuntu-2404/pulls"><img src="https://img.shields.io/github/issues-pr/vaamonde/ubuntu-2404" alt="Pull Requests Badge"/></a>
<a href="https://github.com/vaamonde/ubuntu-2404/issues"><img src="https://img.shields.io/github/issues/vaamonde/ubuntu-2404" alt="Issues Badge"/></a>
<a href="https://github.com/vaamonde/ubuntu-2404/graphs/contributors"><img alt="GitHub contributors" src="https://img.shields.io/github/contributors/vaamonde/ubuntu-2404?color=2b9348"></a>
<a href="https://github.com/vaamonde/ubuntu-2404/blob/master/LICENSE"><img src="https://img.shields.io/github/license/vaamonde/ubuntu-2404?color=2b9348" alt="License Badge"/></a>
</div>

## **🤩🤩 Instalação do Ubuntu Server 24.04.x LTS no Oracle VirtualBOX Projeto Bora para Prática 🤩🤩**

Vídeo de instalação do Ubuntu Server 24.04.x LTS no Oracle VirtualBOX, nesse vídeo você vai aprender a baixar a ISO do Ubuntu Server do site oficial, criar e customizar a máquina virtual no VirtualBOX e fazer a instalação padrão do Ubuntu Server, no próximo vídeo começamos a etapa de configuração.

Conteúdo estudado nessa instalação:<br>
#01_ Download da ISO do Ubuntu Server 24.04.x LTS<br>
#02_ Criação da Máquina Virtual no Oracle VirtualBOX<br>
#03_ Configurações da Máquina Virtual UbuntuWebserver<br>
#04_ Iniciando a Instalação do Ubuntu Server 24.04.x LTS (localizar a ISO)<br>
#05_ Instalação e Configuração do Ubuntu Server 24.04.x LTS<br>
#06_ Acessando o Ubuntu Server pela primeira vez<br>

[![Instalação Ubuntu Server](http://img.youtube.com/vi/p4f6a_-yM_8/0.jpg)](https://www.youtube.com/watch?v=p4f6a_-yM_8 "Instalação Ubuntu Server")

Link da vídeo aula: https://www.youtube.com/watch?v=p4f6a_-yM_8

Link da documentação: https://github.com/vaamonde/ubuntu-2404/blob/main/01-install/01-InstalacaoDoUbuntuServer-24.04-LTS.md